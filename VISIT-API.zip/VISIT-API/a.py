# Code By SAGAR | TG : @STRIKERxSAGAR 
import requests
import telebot
import json
from telebot import types
from html import escape
import logging
import datetime
import time
import threading
from collections import defaultdict
import schedule
from threading import Thread

# ------------------------------------------------- CONFIGURATION -------------------------------------------------
BOT_TOKEN = "8114578847:AAGfeLoSpfYhLjoK76XAEsQRw4GyGgfYSMA"
YOUR_BOT_USERNAME = "fff_info_bot" # WITHOUT @ 

DEVELOPER_NAME = "@rehan_gmr_ff"
OWNER_NAME = "@rehan_gmr_ff"
OWNER_URL = "t.me/rehan_gmr_ff"

# User Limits Configuration
USER_DAILY_LIMIT = 20
OWNER_ID = 8107884145
OWNER_LIMIT = 999 

# ------------------------------------------------- APIS ----------------------------------------------------------
API_VISIT_BASE = "http://127.0.0.1:5003/visit"
# -----------------------------------------------------------------------------------------------------------------

# --- DATA STORAGE ---
user_daily_usage = defaultdict(int)  # user_id -> usage_count
last_reset_date = datetime.datetime.now().date()  # Track last reset date

# --- UTILITY FUNCTIONS ---
def create_promo_markup(add_me_button=False):
    """Creates the standard promotional inline markup."""
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    markup.add(
        types.InlineKeyboardButton(
            text="💎 DEVELOPER",
            url=OWNER_URL
        ),
        types.InlineKeyboardButton(
            text="📊 VIEW STATS",
            callback_data="stats"
        )
    )

    if add_me_button:
        markup.add(
            types.InlineKeyboardButton(
                text="➕ ADD TO GROUP",
                url=f"http://t.me/{YOUR_BOT_USERNAME}?startgroup=start"
            )
        )
        
    return markup

def sanitize_markdown(text):
    """Removes Markdown special characters for safe message display."""
    if text is None:
        return "N/A"
    if not isinstance(text, str):
        text = str(text)
    return text.replace("*", "").replace("_", "").replace("[", "").replace("`", "").strip()

def get_user_limit(user_id):
    """Get the maximum daily uses for a user."""
    return OWNER_LIMIT if user_id == OWNER_ID else USER_DAILY_LIMIT

def get_user_remaining_uses(user_id):
    """Get user's remaining daily visit uses."""
    limit = get_user_limit(user_id)
    return max(0, limit - user_daily_usage[user_id])

def can_user_run_visit(user_id):
    """Check if user can run the visit command."""
    return get_user_remaining_uses(user_id) > 0

def reset_daily_limits():
    """Reset all daily limits at 4 AM."""
    global last_reset_date
    current_date = datetime.datetime.now().date()
    
    if current_date != last_reset_date:
        user_daily_usage.clear()
        last_reset_date = current_date
        logger.info("✅ Daily limits reset at 4 AM")

def schedule_reset():
    """Schedule daily reset at 4 AM."""
    while True:
        try:
            now = datetime.datetime.now()
            if now.hour == 4 and now.minute == 0:
                reset_daily_limits()
                time.sleep(61)
            else:
                time.sleep(30)
        except Exception as e:
            logger.error(f"Error in scheduler: {e}")
            time.sleep(60)

# INITIALIZE BOT
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="Markdown")
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Start background scheduler for daily reset
scheduler_thread = Thread(target=schedule_reset, daemon=True)
scheduler_thread.start()

# ------------------------------------------------- HANDLERS -------------------------------------------------

@bot.message_handler(commands=['start', 'help'])
def start_handler(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    reset_daily_limits()
    
    remaining_uses = get_user_remaining_uses(user_id)
    daily_limit = get_user_limit(user_id)
    
    # Premium Single Line Design
    msg_parts = [
        "━" * 35 + "\n",
        f"👋 *WELCOME {user_name.upper()}!*\n",
        "━" * 35 + "\n\n",
        
        f"⚡ *DAILY USAGE* ➜ `{remaining_uses}/{daily_limit}`\n",
        f"⏰ *RESET TIME* ➜ `4:00 AM`\n\n",
        
        f"🚀 *BOT COMMAND*\n",
        f"`/visit <region> <uid> <limit>`\n\n",

        f"📱 *EXAMPLE*\n",
        f"`/visit IND 9810902977 1000`\n\n",
        
        f"💎 *PREMIUM FEATURES*\n",
        f"• Fast API Processing\n",
        f"• Mobile Optimized\n",
        f"• Daily Auto-Reset\n",
        f"• Real-time Stats\n\n",
    ]
    
    if remaining_uses == 0 and user_id != OWNER_ID:
        msg_parts.append(f"⚠️ *LIMIT REACHED! TRY AGAIN TOMORROW*\n\n")
        
    msg_parts.append("━" * 35 + "\n")
    msg_parts.append(f"🔥 *BOT BY @AGAJAYOFFICIAL*")
    
    markup = create_promo_markup(add_me_button=True)
    
    bot.send_message(chat_id, "".join(msg_parts), reply_markup=markup)

@bot.message_handler(commands=['visit'])
def visit_command(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    args = message.text.split()[1:]
    final_markup = create_promo_markup()

    reset_daily_limits()

    if not can_user_run_visit(user_id):
        limit = get_user_limit(user_id)

        bot.reply_to(
            message,
            f"━" * 35 + "\n"
            f"🚫 *DAILY LIMIT REACHED*\n"
            f"━" * 35 + "\n\n"
            f"📊 *USAGE* ➜ `0/{limit}`\n"
            f"⏰ *RESET* ➜ `4:00 AM`\n"
            f"🎫 *REMAINING* ➜ `0`\n\n"
            f"🔁 *PLEASE TRY AGAIN TOMORROW*\n\n"
            f"━" * 35
        )
        return

    if len(args) < 3:
        bot.reply_to(
            message,
            "⚠️ *INVALID FORMAT*\n\n"
            "📝 *CORRECT USAGE*\n"
            "`/visit <region> <uid> <limit>`\n\n"
            "📌 *EXAMPLE*\n"
            "`/visit IND 9810902977 1000`"
        )
        return

    region = args[0].upper()
    uid = args[1]
    visit_limit = args[2]

    try:
        visit_limit = int(visit_limit)

        if visit_limit <= 0:
            raise ValueError

    except ValueError:
        bot.reply_to(
            message,
            "⚠️ *INVALID LIMIT*\n\n"
            "Limit positive number hona chahiye.\n\n"
            "📌 *EXAMPLE*\n"
            "`/visit IND 9810902977 1000`"
        )
        return

    processing = bot.reply_to(
        message,
        f"⏳ *PROCESSING VISIT*\n"
        f"📱 UID: `{uid}`\n"
        f"🌍 REGION: `{region}`\n"
        f"🎯 LIMIT: `{visit_limit}`\n"
        f"⏰ Please wait...",
        parse_mode="Markdown"
    )

    user_daily_usage[user_id] += 1
    remaining_uses = get_user_remaining_uses(user_id)

    try:
        res = requests.get(
            API_VISIT_BASE,
            params={
                "region": region,
                "uid": uid,
                "limit": visit_limit
            },
            timeout=120
        )

        if res.status_code != 200:
            bot.edit_message_text(
                f"❌ *REQUEST FAILED*\n"
                f"📊 Status: `{res.status_code}`\n"
                f"🔧 Please try again",
                chat_id,
                processing.message_id,
                reply_markup=final_markup,
                parse_mode="Markdown"
            )
            return

        # Flask API text/event-stream response
        data = None

        for line in res.iter_lines(decode_unicode=True):
            if not line:
                continue

            if line.startswith("data:"):
                try:
                    parsed = json.loads(line[5:].strip())

                    if parsed.get("status") in ("completed", "failed"):
                        data = parsed
                        break

                except json.JSONDecodeError:
                    continue

        if data is None:
            bot.edit_message_text(
                "❌ *API RESPONSE ERROR*\n\n"
                "📡 Valid response nahi mila.",
                chat_id,
                processing.message_id,
                reply_markup=final_markup,
                parse_mode="Markdown"
            )
            return

        if data.get("status") == "failed":
            bot.edit_message_text(
                f"❌ *VISIT FAILED*\n\n"
                f"📱 UID: `{uid}`\n"
                f"🔧 Error: `{data.get('error', 'Unknown error')}`",
                chat_id,
                processing.message_id,
                reply_markup=final_markup,
                parse_mode="Markdown"
            )
            return

        nickname = sanitize_markdown(
            data.get("nickname", "N/A")
        )

        fetched_uid = data.get("uid", "N/A")

        success = int(
            data.get("success", 0)
        )

        fail = int(
            data.get("fail", 0)
        )

        level = data.get(
            "level", "N/A"
        )

        likes = data.get(
            "likes", 0
        )

        total = success + fail

        try:
            formatted_likes = "{:,}".format(
                int(likes)
            )
        except (ValueError, TypeError):
            formatted_likes = "N/A"

        percent_success = (
            success / total * 100
            if total > 0
            else 0
        )

        msg = (
            f"━" * 35 + "\n"
            f"✅ *VISIT SUCCESSFUL*\n"
            f"━" * 35 + "\n\n"

            f"👤 *PLAYER INFO*\n"
            f"➤ Name: `{nickname}`\n"
            f"➤ UID: `{fetched_uid}`\n"
            f"➤ Level: `{level}`\n"
            f"➤ Likes: `{formatted_likes}`\n\n"

            f"📊 *VISIT STATS*\n"
            f"➤ Successful: `{success}`\n"
            f"➤ Failed: `{fail}`\n"
            f"➤ Total: `{total}`\n"
            f"➤ Rate: `{percent_success:.1f}%`\n\n"

            f"🎯 *REQUEST LIMIT* ➜ `{visit_limit}`\n\n"

            f"🎫 *YOUR USAGE*\n"
            f"➤ Remaining: "
            f"`{remaining_uses}/{get_user_limit(user_id)}`\n"
            f"➤ Reset: `4:00 AM`\n\n"

            f"━" * 35 + "\n"
            f"💎 *BOT BY @AGAJAYOFFICIAL*"
        )

        bot.edit_message_text(
            msg,
            chat_id,
            processing.message_id,
            reply_markup=final_markup,
            parse_mode="Markdown"
        )

    except requests.exceptions.Timeout:
        bot.edit_message_text(
            "⏰ *TIMEOUT ERROR*\n"
            "📱 Please try again",
            chat_id,
            processing.message_id,
            reply_markup=final_markup,
            parse_mode="Markdown"
        )

    except requests.exceptions.RequestException as e:
        logger.error(
            f"Request Error: {e}"
        )

        bot.edit_message_text(
            "🌐 *NETWORK ERROR*\n"
            "📶 Check connection",
            chat_id,
            processing.message_id,
            reply_markup=final_markup,
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(
            f"Unexpected Error for user {user_id}: {e}"
        )

try:
    bot.edit_message_text(
        msg[:4000],
        chat_id,
        processing.message_id,
        reply_markup=final_markup,
        parse_mode="Markdown"
    )
except Exception as e:
    logger.error(f"Telegram edit error: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "stats")
def stats_callback(call):
    user_id = call.from_user.id
    user_name = call.from_user.first_name
    remaining = get_user_remaining_uses(user_id)
    total_used = user_daily_usage[user_id]
    limit = get_user_limit(user_id)
    
    percentage_used = (total_used/limit*100) if limit > 0 else 0
    filled = int(percentage_used / 10)
    progress_bar = "█" * filled + "░" * (10 - filled)
    
    stats_msg = (
        f"━" * 35 + "\n"
        f"📊 *{user_name}'s STATS*\n"
        f"━" * 35 + "\n\n"
        
        f"🎯 *LIMITS*\n"
        f"➤ Total: `{limit}`\n"
        f"➤ Used: `{total_used}`\n"
        f"➤ Left: `{remaining}`\n\n"
        
        f"📈 *PROGRESS*\n"
        f"{progress_bar} `{percentage_used:.0f}%`\n\n"
        
        f"⏰ *RESET*\n"
        f"➤ Time: `4:00 AM`\n\n"
        
        f"👑 *ACCOUNT*\n"
        f"➤ Type: `{'OWNER' if user_id == OWNER_ID else 'USER'}`\n\n"
        
        f"━" * 35 + "\n"
        f"💡 *Use visits wisely!*"
    )
    
    bot.answer_callback_query(call.id)
    bot.edit_message_text(
        stats_msg,
        call.message.chat.id,
        call.message.message_id,
        reply_markup=create_promo_markup(),
        parse_mode="Markdown"
    )

if __name__ == "__main__":
    print("━" * 35)
    print("🤖 PREMIUM BOT STARTING")
    print("━" * 35)
    print("⚡ VISIT SYSTEM: ACTIVE")
    print(f"🎫 USER LIMIT: {USER_DAILY_LIMIT}")
    print(f"👑 OWNER LIMIT: {OWNER_LIMIT}")
    print("⏰ RESET TIME: 4:00 AM")
    print("📱 PREMIUM DESIGN")
    print("━" * 35)
    bot.infinity_polling()
    
    
    
#MADE BY AJAY PAPA 
#MADE BY AGAJAYOFFICIAL 